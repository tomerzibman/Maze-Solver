# -------------------------------------#
# Programmer: Tomer Zibman
# Description: This program solves a maze of arbitrary size.
# The program follows the algorithm described on the following website:
# http://www.cs.bu.edu/teaching/alg/maze/
# -------------------------------------#
# ---------------------------------------#
# Functions                             #
# ---------------------------------------#
def load_maze(fname):
    '''
    (text file) -> (2d list)
    Supposed to open a text file, read it, and return a 2d list that
    represents the maze in the file.
    '#' - represents a wall
    ' ' - represents open space
    '''
    line = " "
    row = 0
    m2d = []
    m = open(fname, 'r')
    while (line != ''):
        line = m.readline()  # read lines of the text file
        line = line[0:-1]  # remove last 'new line' char
        if (len(line) > 1):
            m2d.append([])  # append empty lists to the list
            for char in line:
                m2d[row].append(char)  # appends the characters to the sub lists
            row += 1
    return m2d  # returnt the 2d list


def print_maze(a_maze):
    '''
    (2d list)
    Prints a 2d list in the format of a maze.
    '''
    cnt = 0  # set counter = 0
    for i in a_maze:  # loop through the maze
        for j in (i):
            print(j, end='')  # print the characters
            cnt += 1
            if cnt % len(i) == 0:  # print in a stright lines until you have reached the end of the line
                print()


def random_coordinates_generator(m):
    '''
    (2d list) -> (int, int)
    Recives a 2d list and generates random x (column) and y (row) coordinates
    on valid spot in the maze.
    '''
    finish = False
    m_height = len(m)
    m_width = len(m[0])
    while (finish == False):
        x = random.randint(1, m_width - 2)  # because first & last cols are always walls
        y = random.randint(1, m_height - 2)  # because first & last rows are always walls
        if (m[y][x] == ' '):
            finish = True
    return y, x


def maze_solver(a_maze, s, g):
    '''
    (2d list, start posotion coordinates, goal position coordinates) -> (True or False)
    Uses recursion to solve the maze and go from the start to the goal positions
    on the maze. Leaves a plus sign to indicate the path it took to get from the
    start position to the goal position.
    '''
    global first_time
    m_height = len(a_maze)
    m_width = len(a_maze[0])
    if (s[0] < 0 or s[0] > m_height - 1 or s[1] < 0 or s[1] > m_width - 1):  # make sure inside the maze
        return False
    m = a_maze[s[0]][s[1]]
    if m == 'G':  # we reached the goal!
        return True
    elif m == '#':  # we hit a wall
        return False
    elif (m == '+' or (m == 'S' and first_time == False)):  # we already been here before
        return False

    if (m == ' '):  # don't erase the 'S'
        first_time = False
        a_maze[s[0]][s[1]] = '+'  # leave a trace

    if (maze_solver(a_maze, [s[0] - 1, s[1]], g)):  # try north
        return True
    if (maze_solver(a_maze, [s[0], s[1] - 1], g)):  # try east
        return True
    if (maze_solver(a_maze, [s[0] + 1, s[1]], g)):  # try south
        return True
    if (maze_solver(a_maze, [s[0], s[1] + 1], g)):  # try west
        return True
    a_maze[s[0]][s[1]] = ' '  # wrong route -> erase trace
    return False


# ---------------------------------------#
# Main Program                          #
# ---------------------------------------#
import random

fname = input("Enter the file name 'maze.txt', 'maze3x3.txt', or 'maze5x15.txt': ")
maze = load_maze(fname)
# generate random start and goal locations
Sr, Sc = random_coordinates_generator(maze)
maze[Sr][Sc] = 'S'
Gr, Gc = random_coordinates_generator(maze)
maze[Gr][Gc] = 'G'
print('\nHere is the maze with start and goal locations:')
print_maze(maze)
s = [Sr, Sc]
g = [Gr, Gc]
print('\nHere is the maze with the path from start to goal:')
first_time = True
maze_solver(maze, s, g)
for r in range(len(maze)):
    for c in range(len(maze[0])):
        if maze[r][c] == ' ':
            maze[r][c] = '.'
print_maze(maze)
